PRIVATE_KEY = "<your wallet's private key>"
ETH_RPC_ENDPOINT = "https://mainnet.infura.io/v3/<your infura key>"
ORG_ID = "naint"
SERVICE_ID = "speech2text-multi"
