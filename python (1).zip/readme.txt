INSTRUCTIONS:
1.speech2text-multi-proto contains proto files of the service.
2.speech2text-multi-grpc-stubs contains compiled grpc stubs required for invoking the service.
3.speech2text-multi-boilerplate contains the sample code.
NOTE:Please follow instructions provided in the python tab of install and run on how to invoke the service.